package springmvc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Application_Status {

	@Id
    @GeneratedValue
    private Integer id;

	private String App_status;
	

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getApp_status() {
		return App_status;
	}

	public void setApp_status(String app_status) {
		App_status = app_status;
	}

	
}
