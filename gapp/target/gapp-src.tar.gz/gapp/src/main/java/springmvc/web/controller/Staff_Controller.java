package springmvc.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Staff_Controller {
	
	@RequestMapping(value={"/Staff/staff_form.html"})
    public String staff( )
    {
        return "Staff/staff_form";
    }

}
