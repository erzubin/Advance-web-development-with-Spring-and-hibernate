package springmvc.model.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTransactionalTestNGSpringContextTests;
import org.testng.annotations.Test;

@Test(groups = "TermDaoTest")
@ContextConfiguration(locations = "classpath:applicationContext.xml")
public class TermDaoTest extends AbstractTransactionalTestNGSpringContextTests {

    @Autowired
    TermDao termDao;

   
    @Test
    public void getTerm()
    {
        //assert termDao.getTerm("Accounting Department","Fall 2016") == 1;
    }

}