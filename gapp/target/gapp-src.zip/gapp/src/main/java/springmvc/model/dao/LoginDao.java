package springmvc.model.dao;

import java.util.List;

import springmvc.model.Members;

public interface LoginDao {
	
	List<Members> getMembers(String username , String password);

}
