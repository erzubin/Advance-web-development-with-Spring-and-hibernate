package springmvc.model.dao;

public interface TermDao {
	
	int getTerm( String dep_name, String term  );


}
