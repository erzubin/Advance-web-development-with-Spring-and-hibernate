drop table application cascade;
drop table application_degree_of_university cascade;
drop table application_status cascade;
drop table degree_of_university cascade;
drop table department cascade;
drop table members cascade;
drop table program cascade;
drop table users cascade;
drop table otherField cascade;
drop table otherfieldvalue cascade;


drop sequence hibernate_sequence;